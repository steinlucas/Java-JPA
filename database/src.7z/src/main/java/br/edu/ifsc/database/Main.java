/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsc.database;

import java.sql.SQLException;

import br.edu.ifsc.database.entity.Cliente;
import br.edu.ifsc.database.entity.Orcamento;

public class Main {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
    	
        Cliente c1 = new Cliente((long)1, "Lucas", "47992843101", "12987634951");
        Cliente c2 = new Cliente((long)2, "Stein", "47999999999", "15584653214");
        Cliente c3 = new Cliente((long)3, "IFSC" , "47988888888", "12345678901");
        
        System.out.println("Cadastrando clientes:");
        ClienteDAO cdao = ClienteDAO.getInstance();
        cdao.save(c1);
        cdao.save(c2);
        cdao.save(c3);

        System.out.println("Mostrando clientes cadastrados:");
        for (Cliente cliente : cdao.getAll()) {
            System.out.println(cliente);
        }
        
        System.out.println("Removendo clientes:");
        cdao.remove(c1);
        cdao.remove(c2);
        cdao.remove(c3);
        
        System.out.println("Mostrando clientes cadastrados (vazio):");
        for (Cliente cliente : cdao.getAll()) {
            System.out.println(cliente);
        }
        
        Orcamento o1 = new Orcamento((long)1, 50, "01/10/2022");
        Orcamento o2 = new Orcamento((long)2, 21, "28/04/2001");
        Orcamento o3 = new Orcamento((long)3, 22, "28/04/2023");
        
        OrcamentoDAO odao = OrcamentoDAO.getInstance();
        odao.save(o1);
        odao.save(o2);
        odao.save(o3);
    }

}
